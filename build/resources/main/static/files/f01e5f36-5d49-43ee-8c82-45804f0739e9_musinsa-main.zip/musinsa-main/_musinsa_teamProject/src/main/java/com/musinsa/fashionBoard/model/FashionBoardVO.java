package com.musinsa.fashionBoard.model;

import lombok.Getter;
import lombok.Setter;

@Getter @Setter
public class FashionBoardVO {
	String test;
}
